const sqlite=require('sqlite3');
const db=new sqlite("../mytest.db");

exports.db=db;