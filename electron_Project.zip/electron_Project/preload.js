const { contextBridge } = require('electron');
const testMgr=require("./models/testmgr");

const getNames =()=>{
    return testMgr.getNames();
}

contextBridge.exposeInMainWorld("api",{
    getNames:getNames
})
