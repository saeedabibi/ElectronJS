 document.addEventListener('DOMContentLoaded',async()=>{
    let names=window.api.getNames();
    let divName= document.getElementById("names");
    let nameString=names.join("<br />");
    divName.innerHTML=nameString;
}) 

