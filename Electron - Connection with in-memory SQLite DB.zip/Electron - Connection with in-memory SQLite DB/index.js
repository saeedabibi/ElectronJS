const sqlite=require('sqlite3').verbose();
let db=new sqlite.Database(':memory:',(err)=>{
    if(err){
        return console.error(err.message);
    }
    console.log('Connected to the in-memory SQLite Database')
});