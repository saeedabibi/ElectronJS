// Initialize the database
const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('db/persons.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the persons database.');
});

// Adds a person
exports.addPerson = function(id, firstname, lastname) {

  // Create the person object
  var person = {
    "id":id,
    "firstname": firstname,
    "lastname": lastname
  };

  
  db.serialize(() => {
    db.run("INSERT INTO persons VALUES (?, ?, ?)", [id, firstname, lastname], (err, row) => {
      if (err) {
        console.error(err.message);
      }
      //console.log(row.firstname + "\t" + row.lastname);
    });
  });
 
};

let sql = `SELECT id,firstname,lastname FROM persons`;
 // Returns all persons
exports.getPersons = function(fnc) {

  // Get all persons from the database
  db.serialize(() => {
    db.all(sql, [], (err, rows) => {
      if (err) {
        throw err;
      }
      rows.forEach((row) => {
        console.log(row.id + "\t" + row.firstname+ "\t" + row.lastname);
        
      });
      fnc(rows);
    });
  });
};


// Deletes a person
exports.deletePerson = function(id) {
   
    db.run('DELETE FROM persons WHERE id = ?', [id], function(err) {
    if (err) {
      console.error(err.message);
    } else {
      console.log(`Row(s) deleted: ${this.changes}`);
    }
  });
} 
