const sqlite3 = require('sqlite3').verbose();

// Connect to the database
const db = new sqlite3.Database('./db/mydatabase.db');

// Retrieve the form data and check it against the database
document.querySelector('#login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.querySelector('#email-input').value;
  const password = document.querySelector('#password-input').value;

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
    if (err) {
      console.error(err.message);
      return;
    }

    if (!row) {
      console.log(`No user found with email ${email}`);
      return;
    }

    if (row.password !== password) {
      console.log('Incorrect password');
      return;
    }

    console.log(`User with ID ${row.id} logged in`);
  });
});
