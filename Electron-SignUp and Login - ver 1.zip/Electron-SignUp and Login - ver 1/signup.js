const sqlite3 = require('sqlite3').verbose();

// Connect to the database
const db = new sqlite3.Database('./db/mydatabase.db');

// Create the users table if it doesn't exist
db.run(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
  )
`);

// Retrieve the form data and insert it into the database
document.querySelector('#signup-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.querySelector('#name-input').value;
  const email = document.querySelector('#email-input').value;
  const password = document.querySelector('#password-input').value;

  db.run('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, password], function(err) {
    if (err) {
      console.error(err.message);
      return;
    }
    console.log(`User with ID ${this.lastID} added to database`);
  });
});
