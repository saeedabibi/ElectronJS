const express = require('express');
const mysql = require("mysql")
const sqlite3=require("sqlite3");
const path = require("path")
const dotenv = require('dotenv')
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")


dotenv.config({ path: './.env'})

const app = express();


/* const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
}) */

var db=  new sqlite3.Database('./mcu.db', sqlite3.OPEN_READWRITE, (err) => {
    if (err && err.code == "SQLITE_CANTOPEN") {
        createDatabase();
        return;
    } else if (err) {
        console.log("Getting error " + err);
        exit(1);
    }
    //runQueries(db);
});

function createDatabase() {
    var newdb = new sqlite3.Database('mcu.db', (err) => {
    if (err) {
        console.log("Getting error " + err);
        exit(1);
    }
        createTables(newdb);
    });
}

function createTables(newdb) {
    newdb.exec(`
    create table users (
        id int primary key not null,
        name text not null,
        email text not null,
        password text not null
    );`
   , ()  => {

    });
}

const publicDir = path.join(__dirname, './public')

app.use(express.static(publicDir))
app.use(express.urlencoded({extended: 'false'}))
app.use(express.json())

app.set('view engine', 'hbs')

/* db.connect((error) => {
    if(error) {
        console.log(error)
    } else {
        console.log("MySQL connected!")
    }
}) */

app.get("/", (req, res) => {
    res.render("index")
})

app.get("/register", (req, res) => {
    res.render("register")
})

app.get("/login", (req, res) => {
    res.render("login")
})


app.post("/auth/register", (req, res) => {    
    const { name, email, password, password_confirm } = req.body
   
    db.get(`SELECT email FROM users WHERE email = ?`, [email], async (error, result) => {
   
        if(error){
            console.log(error)
        }
        console.log(result);

        if(typeof(result) ==='undefined'){
        }
        else{
            if( result.length > 0 ) {
                return res.render('register', {
                    message: 'This email is already in use'
                })
            } else if(password !== password_confirm) {
                return res.render('register', {
                    message: 'Password Didn\'t Match!'
                })
            }
        }        
        
        
        let hashedPassword =  await bcrypt.hash(password, 8)

       // console.log("hashedPassword", hashedPassword)
       
        console.log(`INSERT INTO users SET?`, {name: name, email: email, password: hashedPassword});
        db.run(`INSERT INTO users SET?`, {name: name, email: email, password: hashedPassword}, (err, result) => {
            console.log(result);
            if(error) {
                console.log(error)
            } else 
                if(typeof(result) ==='undefined'){
                }
                else{
                    return res.render('register', {
                        message: 'User registered!'
                    
                })

            }
        })        
    })
})

app.listen(5500, ()=> {
    console.log("server started on port 5500")
})
