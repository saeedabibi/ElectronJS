//Connecting to the in-memory SQLite Database
/* const sqlite=require('sqlite3').verbose();
let db=new sqlite.Database(':memory:',(err)=>{
  if(err)
  {
    return console.error(err.message);
  }
  console.log('Connected to the in-memory SQLite Database');
}) */

////////////////////////////////////////////////////////////////
//Connecting to the disk file SQLite Database
/* const sqlite=require('sqlite3').verbose();
let db = new sqlite.Database('./db/chinook.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the chinook database.');
}); */

////////////////////////////////////////////////////////////////



// Modules to control application life and create native browser window
const { app, BrowserWindow } = require('electron')
const path = require('path')

function createWindow () {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  })

  // and load the index.html of the app.
  mainWindow.loadFile('index.html')

  // Open the DevTools.
  // mainWindow.webContents.openDevTools()
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})


// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
//connecting and opening the chinook database, querying data from the playlists table
const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./db/chinook.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the chinook database.');
});

db.serialize(() => {
  db.each(`SELECT id,
                  name
           FROM playlists`, (err, row) => {
    if (err) {
      console.error(err.message);
    }
    console.log(row.id + "\t" + row.name);
  });

  const name = 'John Doe';
  //db.run('CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)');
  db.run('INSERT INTO users(name) VALUES(?)', [name], function(error) {
    if (error) {
      console.error(error.message);
    } else {
      console.log(`A row has been inserted with rowid ${this.lastID}`);
    }
  });
  

  db.each(`SELECT id,
                  name
            FROM Users`, (err, row) => {
  if (err) {
    console.error(err.message);
  }
  console.log(row.id + "\t" + row.name);
});

});

db.close((err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Close the database connection.');
});
